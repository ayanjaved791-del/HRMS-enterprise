import React, { useState } from 'react';
import { HRProvider, useHR } from './context/HRContext';
import { FirstTimeSetup } from './components/auth/FirstTimeSetup';
import { DedicatedLoginPage } from './components/auth/DedicatedLoginPage';
import { SidebarExact } from './components/layout/SidebarExact';
import { TopHeader } from './components/layout/TopHeader';
import { ModuleNavBar } from './components/layout/ModuleNavBar';
import { MobileBottomBar } from './components/layout/MobileBottomBar';
import { CameraPunchModal } from './components/common/CameraPunchModal';
import { SmartAssistantDrawer } from './components/common/SmartAssistantDrawer';
import { AuthModal } from './components/common/AuthModal';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { PayslipModal } from './components/modules/payroll/PayslipModal';

// Admin Core Modules
import { AdminDashboard } from './components/modules/core/AdminDashboard';
import { EmployeeDirectory } from './components/modules/core/EmployeeDirectory';
import { OrgChart } from './components/modules/core/OrgChart';
import { DocumentVault } from './components/modules/core/DocumentVault';
import { RbacMatrix } from './components/modules/core/RbacMatrix';
import { CompanyProfile } from './components/modules/core/CompanyProfile';
import { AdminApplications } from './components/modules/admin/AdminApplications';
import { AdminAnnouncements } from './components/modules/admin/AdminAnnouncements';
import { PayslipDesigner } from './components/modules/admin/PayslipDesigner';
import { ManagerMssDashboard } from './components/modules/core/ManagerMssDashboard';
import { WorkflowBuilder } from './components/modules/core/WorkflowBuilder';
import { AssetLedger } from './components/modules/core/AssetLedger';
import { ApiGateway } from './components/modules/core/ApiGateway';

// Attendance Modules
import { AttendanceOverview } from './components/modules/attendance/AttendanceOverview';
import { LeaveTracker } from './components/modules/attendance/LeaveTracker';
import { ShiftScheduler } from './components/modules/attendance/ShiftScheduler';
import { ProjectTimesheets } from './components/modules/attendance/ProjectTimesheets';
import { HolidayCalendar } from './components/modules/attendance/HolidayCalendar';
import { OvertimeEngine } from './components/modules/attendance/OvertimeEngine';

// Payroll Modules
import { PayrollEngine } from './components/modules/payroll/PayrollEngine';
import { StatutoryTaxCalculator } from './components/modules/payroll/StatutoryTaxCalculator';
import { ExpenseClaims } from './components/modules/payroll/ExpenseClaims';
import { BenefitsPortal } from './components/modules/payroll/BenefitsPortal';
import { MultiCurrencyModule } from './components/modules/payroll/MultiCurrencyModule';

// Talent & Recruitment Modules
import { ApplicantTrackingSystem } from './components/modules/talent/ApplicantTrackingSystem';
import { InterviewScheduler } from './components/modules/talent/InterviewScheduler';
import { DigitalOnboarding } from './components/modules/talent/DigitalOnboarding';
import { BackgroundVerifier } from './components/modules/talent/BackgroundVerifier';
import { OffboardingTracker } from './components/modules/talent/OffboardingTracker';

// Performance Modules
import { OkrGoalTracker } from './components/modules/performance/OkrGoalTracker';
import { AppraisalMatrix } from './components/modules/performance/AppraisalMatrix';
import { CompetencyFramework } from './components/modules/performance/CompetencyFramework';
import { PeerRewardsWall } from './components/modules/performance/PeerRewardsWall';
import { SentimentPulseSurvey } from './components/modules/performance/SentimentPulseSurvey';
import { SuccessionBench } from './components/modules/performance/SuccessionBench';
import { LearningManagementSystem } from './components/modules/performance/LearningManagementSystem';
import { WorkforceAnalytics } from './components/modules/performance/WorkforceAnalytics';

// Employee Dedicated Modules
import { EmployeeEssDashboard } from './components/modules/core/EmployeeEssDashboard';
import { EmployeeAnnouncements } from './components/modules/employee/EmployeeAnnouncements';
import { EmployeeApplications } from './components/modules/employee/EmployeeApplications';
import { EmployeePayslips } from './components/modules/employee/EmployeePayslips';
import { EmployeeProfile } from './components/modules/employee/EmployeeProfile';

import { PayrollRun } from './types';

const MainAppLayout: React.FC = () => {
  const {
    isSetupComplete,
    currentUser,
    activeRole,
    activeSubTab,
    company
  } = useHR();

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [activePayslipRun, setActivePayslipRun] = useState<PayrollRun | null>(null);

  // 1. Guard: If system has never been registered/setup, prompt FirstTimeSetup dedicated screen
  if (!isSetupComplete) {
    return <FirstTimeSetup />;
  }

  // 2. Guard: If user is logged out or visiting from another device, show DedicatedLoginPage
  if (!currentUser) {
    return <DedicatedLoginPage />;
  }

  // 3. Render Viewports for every sub-navigation tab
  const renderActiveView = () => {
    // If Employee Portal: Strictly limited to employee features
    if (activeRole === 'employee') {
      switch (activeSubTab) {
        case 'dashboard':
        case 'employee-ess':
          return <EmployeeEssDashboard />;
        case 'attendance':
        case 'attendance-overview':
          return <AttendanceOverview />;
        case 'project-timesheets':
          return <ProjectTimesheets />;
        case 'leave-management':
        case 'leave-tracker':
        case 'applications':
        case 'employee-applications':
          return <EmployeeApplications />;
        case 'payroll':
        case 'employee-payslips':
          return <EmployeePayslips />;
        case 'announcements':
        case 'employee-announcements':
          return <EmployeeAnnouncements />;
        case 'settings':
        case 'employee-profile':
          return <EmployeeProfile />;
        default:
          return <EmployeeEssDashboard />;
      }
    }

    // Admin Console Viewports (Handles all 13 Image 1 Sidebar Items & Sub-Navigation Tabs)
    switch (activeSubTab) {
      // 1. Dashboard Tabs
      case 'dashboard':
        return <AdminDashboard />;
      case 'admin-applications':
        return <AdminApplications />;
      case 'admin-announcements':
        return <AdminAnnouncements />;
      case 'manager-mss':
        return <ManagerMssDashboard />;

      // 2. Employees Tabs
      case 'employees':
        return <EmployeeDirectory />;
      case 'onboarding':
        return <DigitalOnboarding />;
      case 'offboarding':
        return <OffboardingTracker />;

      // 3. Organization Tabs
      case 'organization':
      case 'org-chart':
        return <OrgChart />;
      case 'workflow-builder':
        return <WorkflowBuilder />;

      // 4. Attendance Tabs
      case 'attendance':
      case 'attendance-overview':
        return <AttendanceOverview />;
      case 'shift-scheduler':
        return <ShiftScheduler />;
      case 'project-timesheets':
        return <ProjectTimesheets />;
      case 'holiday-calendar':
        return <HolidayCalendar />;
      case 'overtime-engine':
        return <OvertimeEngine />;

      // 5. Leave Management Tabs
      case 'leave-management':
      case 'leave-tracker':
        return <LeaveTracker />;
      case 'applications':
        return <AdminApplications />;

      // 6. Payroll Tabs
      case 'payroll':
      case 'payroll-engine':
        return <PayrollEngine onViewPayslip={(run) => setActivePayslipRun(run)} />;
      case 'payslip-studio':
        return <PayslipDesigner />;
      case 'tax-calculator':
        return <StatutoryTaxCalculator />;
      case 'expense-claims':
        return <ExpenseClaims />;
      case 'benefits-portal':
        return <BenefitsPortal />;
      case 'multi-currency':
        return <MultiCurrencyModule />;

      // 7. Recruitment Tabs
      case 'recruitment':
      case 'ats':
        return <ApplicantTrackingSystem />;
      case 'interviews':
        return <InterviewScheduler />;
      case 'background-check':
        return <BackgroundVerifier />;

      // 8. Performance Tabs
      case 'performance':
      case 'okr-goals':
        return <OkrGoalTracker />;
      case 'appraisal-matrix':
        return <AppraisalMatrix />;
      case 'competencies':
        return <CompetencyFramework />;
      case 'peer-rewards':
        return <PeerRewardsWall />;
      case 'pulse-surveys':
        return <SentimentPulseSurvey />;
      case 'succession-bench':
        return <SuccessionBench />;

      // 9. Training Tabs
      case 'training':
      case 'lms':
        return <LearningManagementSystem />;

      // 10. Documents Tabs
      case 'documents':
      case 'document-vault':
        return <DocumentVault />;
      case 'asset-ledger':
        return <AssetLedger />;

      // 11. Reports Tabs
      case 'reports':
      case 'analytics':
        return <WorkforceAnalytics />;

      // 12. User Management Tabs
      case 'user-management':
      case 'rbac':
        return <RbacMatrix />;
      case 'api-gateway':
        return <ApiGateway />;

      // 13. Settings Tabs
      case 'settings':
      case 'company-profile':
        return <CompanyProfile />;

      default:
        return <AdminDashboard />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#F8FAFC]">
      {/* 1. Desktop Exact Image 1 Sidebar (Hidden on mobile < md) */}
      <SidebarExact onOpenAuthModal={() => setIsAuthModalOpen(true)} />

      {/* 2. Main Workspace Viewport */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Top Bar Header (Image 1 Greeting + Date, Image 2 Controls) */}
        <TopHeader
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          onOpenGlobalSearch={() => setIsSearchModalOpen(true)}
        />

        {/* Scrollable Content Viewport with pb-24 for mobile bottom bar */}
        <main className="flex-1 overflow-y-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 max-w-7xl w-full mx-auto pb-24 md:pb-8">
          {/* Sub-Navigation Bar for every sidebar navlink */}
          <ModuleNavBar />

          {/* Active View Content */}
          {renderActiveView()}
        </main>
      </div>

      {/* 3. Mobile Bottom Bar Menu (Shown only on small/mobile screens < md) */}
      <MobileBottomBar />

      {/* Modals & Overlays */}
      <CameraPunchModal />
      <SmartAssistantDrawer />
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
      <GlobalSearchModal isOpen={isSearchModalOpen} onClose={() => setIsSearchModalOpen(false)} />
      <PayslipModal
        run={activePayslipRun}
        company={company}
        onClose={() => setActivePayslipRun(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <HRProvider>
      <MainAppLayout />
    </HRProvider>
  );
}
